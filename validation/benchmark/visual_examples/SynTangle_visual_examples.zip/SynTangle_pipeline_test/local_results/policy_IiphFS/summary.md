# Efficiency overview

| Budget | Start | Variant | Complete/expected | Proven | Median wall s | Median LNS s | Median global s |
|---:|---|---|---:|---:|---:|---:|---:|
| 150 | pre_hybrid | adaptive_control | 9/9 | 6 | 4.02 | 1.37 | 0.69 |
| 150 | pre_hybrid | direct_control | 9/9 | 6 | 2.92 | 0.00 | 0.73 |
| 150 | pre_hybrid | mirror_adaptive | 9/9 | 6 | 3.74 | 1.09 | 0.54 |
| 150 | pre_hybrid | mirror_direct | 9/9 | 6 | 2.37 | 0.00 | 0.36 |
| 150 | pre_hybrid | mirror_selective | 9/9 | 6 | 3.27 | 0.00 | 0.81 |
| 150 | pre_hybrid | mirror_three | 9/9 | 6 | 3.42 | 0.66 | 0.54 |
| 150 | pre_hybrid | three_control | 9/9 | 6 | 3.83 | 1.00 | 0.73 |
| 150 | public | adaptive_control | 9/9 | 6 | 6.28 | 3.14 | 1.05 |
| 150 | public | direct_control | 9/9 | 6 | 3.33 | 0.00 | 1.12 |
| 150 | public | mirror_adaptive | 9/9 | 6 | 6.03 | 2.92 | 0.81 |
| 150 | public | mirror_direct | 9/9 | 6 | 3.32 | 0.00 | 1.05 |
| 150 | public | mirror_selective | 9/9 | 6 | 1.42 | 0.00 | 0.43 |
| 150 | public | mirror_three | 9/9 | 6 | 5.12 | 1.99 | 0.87 |
| 150 | public | three_control | 9/9 | 6 | 6.13 | 2.42 | 1.05 |
| 600 | pre_hybrid | adaptive_control | 6/6 | 6 | 474.50 | 42.35 | 420.34 |
| 600 | pre_hybrid | direct_control | 6/6 | 6 | 482.91 | 0.00 | 474.91 |
| 600 | pre_hybrid | mirror_adaptive | 6/6 | 6 | 375.29 | 44.90 | 316.59 |
| 600 | pre_hybrid | mirror_direct | 6/6 | 6 | 321.25 | 0.00 | 314.13 |
| 600 | pre_hybrid | mirror_selective | 6/6 | 6 | 342.65 | 2.43 | 332.49 |
| 600 | pre_hybrid | mirror_three | 6/6 | 5 | 352.88 | 3.40 | 341.76 |
| 600 | pre_hybrid | three_control | 6/6 | 6 | 450.93 | 3.30 | 439.67 |
| 600 | public | adaptive_control | 6/6 | 6 | 510.74 | 55.15 | 447.59 |
| 600 | public | direct_control | 6/6 | 6 | 451.88 | 0.00 | 444.03 |
| 600 | public | mirror_adaptive | 6/6 | 6 | 366.17 | 58.88 | 300.67 |
| 600 | public | mirror_direct | 6/6 | 6 | 448.55 | 0.00 | 441.36 |
| 600 | public | mirror_selective | 6/6 | 6 | 301.33 | 8.90 | 283.88 |
| 600 | public | mirror_three | 6/6 | 6 | 340.18 | 15.93 | 316.59 |
| 600 | public | three_control | 6/6 | 6 | 457.50 | 15.25 | 433.15 |

Medians describe this fixed mixture of fixtures; compare matched individual cases before ranking methods.

# Efficiency ablation

| Case | Start | Variant | Budget | Repeat | C | Lower | Proven | Prep s | LNS s | Global s | Nodes | RSS MiB | Mirror comps | Status |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---|
| stress_10sp_40chr_12ev_mild | pre_hybrid | adaptive_control | 150 | 0 | 14092 | 4343 | False | 7.04 | 36.83 | 105.97 | 6 | 153.2 | 0 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | adaptive_control | 600 | 0 | 8377 | 8377 | True | 3.28 | 20.23 | 217.03 | 7 | 441.2 | 0 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | adaptive_control | 600 | 1 | 8377 | 8377 | True | 6.78 | 38.56 | 449.55 | 7 | 440.9 | 0 | complete |
| stress_10sp_40chr_12ev_mild | public | adaptive_control | 150 | 0 | 16523 | 4343 | False | 6.44 | 36.97 | 106.43 | 6 | 153.6 | 0 | complete |
| stress_10sp_40chr_12ev_mild | public | adaptive_control | 600 | 0 | 8377 | 8377 | True | 6.85 | 61.37 | 458.77 | 7 | 442.5 | 0 | complete |
| stress_10sp_40chr_12ev_mild | public | adaptive_control | 600 | 1 | 8377 | 8377 | True | 6.90 | 62.54 | 471.16 | 7 | 442.5 | 0 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | direct_control | 150 | 0 | 17768 | 4343 | False | 7.76 | 0.00 | 141.98 | 6 | 133.8 | 0 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | direct_control | 600 | 0 | 8377 | 8377 | True | 6.82 | 0.00 | 468.44 | 7 | 425.3 | 0 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | direct_control | 600 | 1 | 8377 | 8377 | True | 6.69 | 0.00 | 437.09 | 7 | 419.7 | 0 | complete |
| stress_10sp_40chr_12ev_mild | public | direct_control | 150 | 0 | 74306 | 4343 | False | 6.65 | 0.00 | 143.13 | 6 | 130.7 | 0 | complete |
| stress_10sp_40chr_12ev_mild | public | direct_control | 600 | 0 | 8377 | 8377 | True | 3.30 | 0.00 | 219.77 | 7 | 416.7 | 0 | complete |
| stress_10sp_40chr_12ev_mild | public | direct_control | 600 | 1 | 8377 | 8377 | True | 6.59 | 0.00 | 459.23 | 7 | 418.1 | 0 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_adaptive | 150 | 0 | 14092 | 4343 | False | 7.42 | 36.82 | 105.55 | 6 | 150.1 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_adaptive | 600 | 0 | 8377 | 8377 | True | 6.90 | 39.57 | 419.04 | 7 | 640.6 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_adaptive | 600 | 1 | 8377 | 8377 | True | 6.69 | 39.48 | 422.64 | 7 | 634.3 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_adaptive | 150 | 0 | 16523 | 4343 | False | 6.66 | 36.93 | 106.19 | 6 | 153.5 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_adaptive | 600 | 0 | 8377 | 8377 | True | 6.84 | 62.55 | 287.54 | 7 | 675.3 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_adaptive | 600 | 1 | 8377 | 8377 | True | 6.68 | 61.88 | 292.34 | 7 | 679.0 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_direct | 150 | 0 | 17768 | 4343 | False | 7.02 | 0.00 | 142.74 | 6 | 131.5 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_direct | 600 | 0 | 8377 | 8377 | True | 5.43 | 0.00 | 315.10 | 7 | 606.8 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_direct | 600 | 1 | 8377 | 8377 | True | 6.38 | 0.00 | 381.18 | 7 | 607.2 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_direct | 150 | 0 | 74306 | 4343 | False | 6.86 | 0.00 | 142.91 | 6 | 131.6 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_direct | 600 | 0 | 8377 | 8377 | True | 7.05 | 0.00 | 279.42 | 7 | 564.8 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_direct | 600 | 1 | 8377 | 8377 | True | 6.90 | 0.00 | 259.41 | 7 | 568.1 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_selective | 150 | 0 | 14092 | 4343 | False | 7.16 | 20.59 | 122.03 | 6 | 150.9 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_selective | 600 | 0 | 8377 | 8377 | True | 6.96 | 2.49 | 438.46 | 7 | 629.6 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_selective | 600 | 1 | 8377 | 8377 | True | 6.68 | 2.95 | 422.24 | 7 | 639.0 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_selective | 150 | 0 | 17016 | 4343 | False | 6.65 | 21.40 | 121.73 | 6 | 152.4 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_selective | 600 | 0 | 8377 | 8377 | True | 6.78 | 9.31 | 304.08 | 7 | 676.7 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_selective | 600 | 1 | 8377 | 8377 | True | 6.34 | 8.49 | 277.56 | 7 | 674.4 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_three | 150 | 0 | 17768 | 4343 | False | 7.20 | 3.56 | 139.00 | 6 | 153.3 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_three | 600 | 0 | 8377 | 8377 | True | 7.11 | 3.41 | 437.04 | 7 | 641.3 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | mirror_three | 600 | 1 | 8377 | 8264 | False | 6.09 | 3.63 | 344.35 | 6 | 642.2 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_three | 150 | 0 | 23916 | 4343 | False | 6.34 | 12.23 | 131.22 | 6 | 151.9 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_three | 600 | 0 | 8377 | 8377 | True | 6.83 | 13.97 | 325.52 | 7 | 667.4 | 7 | complete |
| stress_10sp_40chr_12ev_mild | public | mirror_three | 600 | 1 | 8377 | 8377 | True | 5.29 | 9.93 | 228.02 | 7 | 670.6 | 7 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | three_control | 150 | 0 | 17768 | 4343 | False | 7.79 | 3.87 | 138.09 | 6 | 151.7 | 0 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | three_control | 600 | 0 | 8377 | 8377 | True | 7.03 | 3.43 | 478.81 | 7 | 441.4 | 0 | complete |
| stress_10sp_40chr_12ev_mild | pre_hybrid | three_control | 600 | 1 | 8377 | 8377 | True | 6.88 | 3.17 | 428.48 | 7 | 433.9 | 0 | complete |
| stress_10sp_40chr_12ev_mild | public | three_control | 150 | 0 | 23916 | 4343 | False | 6.78 | 13.25 | 129.79 | 6 | 153.0 | 0 | complete |
| stress_10sp_40chr_12ev_mild | public | three_control | 600 | 0 | 8377 | 8377 | True | 6.88 | 13.93 | 471.63 | 7 | 438.8 | 0 | complete |
| stress_10sp_40chr_12ev_mild | public | three_control | 600 | 1 | 8377 | 8377 | True | 3.28 | 5.79 | 214.94 | 7 | 439.2 | 0 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | adaptive_control | 150 | 0 | 12346 | 4343 | False | 6.99 | 36.57 | 106.22 | 6 | 152.3 | 0 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | adaptive_control | 600 | 0 | 8377 | 8377 | True | 3.24 | 25.01 | 214.62 | 7 | 441.1 | 0 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | adaptive_control | 600 | 1 | 8377 | 8377 | True | 7.14 | 48.36 | 472.90 | 7 | 435.3 | 0 | complete |
| stress_10sp_40chr_12ev_random | public | adaptive_control | 150 | 0 | 13706 | 4343 | False | 6.37 | 36.99 | 106.47 | 6 | 150.5 | 0 | complete |
| stress_10sp_40chr_12ev_random | public | adaptive_control | 600 | 0 | 8377 | 8377 | True | 7.01 | 57.39 | 442.05 | 7 | 443.5 | 0 | complete |
| stress_10sp_40chr_12ev_random | public | adaptive_control | 600 | 1 | 8377 | 8377 | True | 6.01 | 51.72 | 391.84 | 7 | 444.2 | 0 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | direct_control | 150 | 0 | 14394 | 4230 | False | 7.43 | 0.00 | 142.28 | 5 | 130.9 | 0 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | direct_control | 600 | 0 | 8377 | 8377 | True | 7.08 | 0.00 | 485.20 | 7 | 422.0 | 0 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | direct_control | 600 | 1 | 8377 | 8377 | True | 3.28 | 0.00 | 217.62 | 7 | 420.9 | 0 | complete |
| stress_10sp_40chr_12ev_random | public | direct_control | 150 | 0 | 74306 | 4343 | False | 6.72 | 0.00 | 143.07 | 6 | 130.9 | 0 | complete |
| stress_10sp_40chr_12ev_random | public | direct_control | 600 | 0 | 8377 | 8377 | True | 7.37 | 0.00 | 497.01 | 7 | 415.6 | 0 | complete |
| stress_10sp_40chr_12ev_random | public | direct_control | 600 | 1 | 8377 | 8377 | True | 6.76 | 0.00 | 429.57 | 7 | 423.1 | 0 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_adaptive | 150 | 0 | 12346 | 4343 | False | 7.19 | 36.59 | 105.97 | 6 | 153.2 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_adaptive | 600 | 0 | 8377 | 8377 | True | 6.64 | 44.71 | 281.89 | 7 | 670.8 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_adaptive | 600 | 1 | 8377 | 8377 | True | 7.42 | 50.30 | 327.93 | 7 | 676.3 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_adaptive | 150 | 0 | 14218 | 4343 | False | 7.84 | 36.47 | 105.43 | 6 | 152.5 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_adaptive | 600 | 0 | 8377 | 8377 | True | 7.17 | 62.54 | 438.62 | 7 | 629.4 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_adaptive | 600 | 1 | 8377 | 8377 | True | 6.51 | 55.88 | 400.23 | 7 | 642.8 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_direct | 150 | 0 | 14394 | 4343 | False | 7.38 | 0.00 | 142.33 | 6 | 129.8 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_direct | 600 | 0 | 8377 | 8377 | True | 6.96 | 0.00 | 337.90 | 7 | 653.9 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_direct | 600 | 1 | 8377 | 8377 | True | 6.40 | 0.00 | 288.08 | 7 | 650.6 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_direct | 150 | 0 | 74306 | 4343 | False | 6.64 | 0.00 | 143.17 | 6 | 133.4 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_direct | 600 | 0 | 8377 | 8377 | True | 7.23 | 0.00 | 526.97 | 7 | 514.5 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_direct | 600 | 1 | 8377 | 8377 | True | 6.37 | 0.00 | 458.22 | 7 | 535.7 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_selective | 150 | 0 | 10083 | 8313 | False | 3.30 | 11.12 | 135.54 | 7 | 557.0 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_selective | 600 | 0 | 8377 | 8377 | True | 3.28 | 1.05 | 157.61 | 7 | 676.7 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_selective | 600 | 1 | 8377 | 8377 | True | 7.36 | 2.53 | 323.73 | 7 | 660.8 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_selective | 150 | 0 | 14318 | 4343 | False | 7.86 | 21.26 | 120.61 | 6 | 149.9 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_selective | 600 | 0 | 8377 | 8377 | True | 3.26 | 5.59 | 205.79 | 7 | 637.3 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_selective | 600 | 1 | 8377 | 8377 | True | 7.22 | 13.00 | 436.80 | 7 | 629.7 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_three | 150 | 0 | 14394 | 4343 | False | 7.35 | 3.49 | 138.94 | 6 | 151.1 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_three | 600 | 0 | 8377 | 8377 | True | 6.03 | 2.98 | 260.91 | 7 | 678.8 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | mirror_three | 600 | 1 | 8377 | 8377 | True | 6.67 | 3.24 | 297.15 | 7 | 678.1 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_three | 150 | 0 | 19230 | 4343 | False | 6.65 | 15.64 | 127.51 | 6 | 152.5 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_three | 600 | 0 | 8377 | 8377 | True | 7.22 | 18.07 | 450.01 | 7 | 628.6 | 7 | complete |
| stress_10sp_40chr_12ev_random | public | mirror_three | 600 | 1 | 8377 | 8377 | True | 6.04 | 15.08 | 357.62 | 7 | 638.4 | 7 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | three_control | 150 | 0 | 14394 | 4343 | False | 7.03 | 3.30 | 139.47 | 6 | 153.3 | 0 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | three_control | 600 | 0 | 8377 | 8377 | True | 6.49 | 3.06 | 417.54 | 7 | 441.8 | 0 | complete |
| stress_10sp_40chr_12ev_random | pre_hybrid | three_control | 600 | 1 | 8377 | 8377 | True | 6.95 | 3.50 | 450.85 | 7 | 438.6 | 0 | complete |
| stress_10sp_40chr_12ev_random | public | three_control | 150 | 0 | 19250 | 4230 | False | 6.06 | 15.23 | 128.48 | 5 | 152.2 | 0 | complete |
| stress_10sp_40chr_12ev_random | public | three_control | 600 | 0 | 8377 | 8377 | True | 6.98 | 16.56 | 446.33 | 7 | 438.2 | 0 | complete |
| stress_10sp_40chr_12ev_random | public | three_control | 600 | 1 | 8377 | 8377 | True | 7.00 | 18.57 | 484.12 | 7 | 440.6 | 0 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | adaptive_control | 150 | 0 | 11582 | 4230 | False | 6.79 | 36.47 | 106.55 | 5 | 172.3 | 0 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | adaptive_control | 600 | 0 | 8377 | 8377 | True | 6.41 | 47.01 | 423.05 | 7 | 441.9 | 0 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | adaptive_control | 600 | 1 | 8377 | 8377 | True | 6.50 | 46.14 | 417.64 | 7 | 431.1 | 0 | complete |
| stress_10sp_40chr_12ev_strong | public | adaptive_control | 150 | 0 | 22699 | 4343 | False | 7.22 | 36.69 | 105.91 | 6 | 155.2 | 0 | complete |
| stress_10sp_40chr_12ev_strong | public | adaptive_control | 600 | 0 | 8377 | 8377 | True | 7.00 | 52.91 | 453.13 | 7 | 437.7 | 0 | complete |
| stress_10sp_40chr_12ev_strong | public | adaptive_control | 600 | 1 | 8377 | 8377 | True | 3.30 | 26.71 | 215.34 | 7 | 438.0 | 0 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | direct_control | 150 | 0 | 16605 | 4343 | False | 5.29 | 0.00 | 144.54 | 6 | 133.7 | 0 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | direct_control | 600 | 0 | 8377 | 8377 | True | 7.98 | 0.00 | 525.96 | 7 | 409.3 | 0 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | direct_control | 600 | 1 | 8377 | 8377 | True | 7.19 | 0.00 | 481.39 | 7 | 423.3 | 0 | complete |
| stress_10sp_40chr_12ev_strong | public | direct_control | 150 | 0 | 74306 | 8232 | False | 3.27 | 0.00 | 146.74 | 6 | 394.6 | 0 | complete |
| stress_10sp_40chr_12ev_strong | public | direct_control | 600 | 0 | 8377 | 8377 | True | 6.76 | 0.00 | 432.55 | 7 | 416.1 | 0 | complete |
| stress_10sp_40chr_12ev_strong | public | direct_control | 600 | 1 | 8377 | 8377 | True | 6.70 | 0.00 | 455.50 | 7 | 419.7 | 0 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_adaptive | 150 | 0 | 11582 | 4343 | False | 6.81 | 36.33 | 106.65 | 6 | 162.0 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_adaptive | 600 | 0 | 8377 | 8377 | True | 6.39 | 45.10 | 273.25 | 7 | 697.4 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_adaptive | 600 | 1 | 8377 | 8377 | True | 6.94 | 50.60 | 305.25 | 7 | 690.7 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_adaptive | 150 | 0 | 22696 | 4343 | False | 6.71 | 36.83 | 106.23 | 6 | 153.6 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_adaptive | 600 | 0 | 8377 | 8377 | True | 6.55 | 47.82 | 265.18 | 7 | 674.6 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_adaptive | 600 | 1 | 8377 | 8377 | True | 7.15 | 52.97 | 309.00 | 7 | 677.0 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_direct | 150 | 0 | 16605 | 4343 | False | 6.40 | 0.00 | 143.32 | 6 | 131.2 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_direct | 600 | 0 | 8377 | 8377 | True | 6.73 | 0.00 | 297.44 | 7 | 645.2 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_direct | 600 | 1 | 8377 | 8377 | True | 7.02 | 0.00 | 313.17 | 7 | 652.2 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_direct | 150 | 0 | 74306 | 4343 | False | 6.92 | 0.00 | 142.87 | 6 | 135.2 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_direct | 600 | 0 | 8377 | 8377 | True | 6.08 | 0.00 | 424.51 | 7 | 531.5 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_direct | 600 | 1 | 8377 | 8377 | True | 6.75 | 0.00 | 488.82 | 7 | 522.1 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_selective | 150 | 0 | 11582 | 4343 | False | 6.40 | 21.45 | 121.96 | 6 | 166.4 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_selective | 600 | 0 | 8377 | 8377 | True | 6.57 | 2.37 | 328.65 | 7 | 740.4 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_selective | 600 | 1 | 8377 | 8377 | True | 6.94 | 2.37 | 336.32 | 7 | 755.1 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_selective | 150 | 0 | 22761 | 4230 | False | 7.08 | 21.24 | 121.47 | 5 | 156.9 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_selective | 600 | 0 | 8377 | 8377 | True | 6.52 | 11.69 | 290.19 | 7 | 785.5 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_selective | 600 | 1 | 8377 | 8377 | True | 3.29 | 5.68 | 164.03 | 7 | 788.5 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_three | 150 | 0 | 16605 | 4343 | False | 6.74 | 3.43 | 139.62 | 6 | 153.2 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_three | 600 | 0 | 8377 | 8377 | True | 6.69 | 3.50 | 339.16 | 7 | 771.0 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | mirror_three | 600 | 1 | 8377 | 8377 | True | 6.95 | 3.39 | 345.58 | 7 | 749.8 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_three | 150 | 0 | 25540 | 4343 | False | 6.96 | 17.90 | 124.89 | 6 | 151.6 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_three | 600 | 0 | 8377 | 8377 | True | 6.45 | 16.78 | 291.20 | 7 | 768.7 | 7 | complete |
| stress_10sp_40chr_12ev_strong | public | mirror_three | 600 | 1 | 8377 | 8377 | True | 6.69 | 17.49 | 307.65 | 7 | 776.4 | 7 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | three_control | 150 | 0 | 16605 | 4343 | False | 7.11 | 3.48 | 139.20 | 6 | 153.8 | 0 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | three_control | 600 | 0 | 8377 | 8377 | True | 7.95 | 3.99 | 517.36 | 7 | 434.2 | 0 | complete |
| stress_10sp_40chr_12ev_strong | pre_hybrid | three_control | 600 | 1 | 8377 | 8377 | True | 6.64 | 3.14 | 427.51 | 7 | 437.8 | 0 | complete |
| stress_10sp_40chr_12ev_strong | public | three_control | 150 | 0 | 25540 | 8130 | False | 3.25 | 8.23 | 138.45 | 6 | 424.1 | 0 | complete |
| stress_10sp_40chr_12ev_strong | public | three_control | 600 | 0 | 8377 | 8377 | True | 6.42 | 16.83 | 419.98 | 7 | 434.9 | 0 | complete |
| stress_10sp_40chr_12ev_strong | public | three_control | 600 | 1 | 8377 | 8377 | True | 3.26 | 8.15 | 214.45 | 7 | 438.3 | 0 | complete |
| stress_6sp_20chr_5ev_mild | pre_hybrid | adaptive_control | 150 | 0 | 341 | 341 | True | 0.19 | 0.00 | 0.20 | 5 | 50.8 | 0 | complete |
| stress_6sp_20chr_5ev_mild | public | adaptive_control | 150 | 0 | 341 | 341 | True | 0.35 | 0.00 | 0.41 | 8 | 51.9 | 0 | complete |
| stress_6sp_20chr_5ev_mild | pre_hybrid | direct_control | 150 | 0 | 341 | 341 | True | 0.20 | 0.00 | 0.23 | 5 | 50.9 | 0 | complete |
| stress_6sp_20chr_5ev_mild | public | direct_control | 150 | 0 | 341 | 341 | True | 0.34 | 0.00 | 0.49 | 8 | 51.8 | 0 | complete |
| stress_6sp_20chr_5ev_mild | pre_hybrid | mirror_adaptive | 150 | 0 | 341 | 341 | True | 0.21 | 0.00 | 0.20 | 4 | 50.4 | 5 | complete |
| stress_6sp_20chr_5ev_mild | public | mirror_adaptive | 150 | 0 | 341 | 341 | True | 0.32 | 0.00 | 0.63 | 7 | 50.9 | 8 | complete |
| stress_6sp_20chr_5ev_mild | pre_hybrid | mirror_direct | 150 | 0 | 341 | 341 | True | 0.21 | 0.00 | 0.22 | 4 | 50.3 | 5 | complete |
| stress_6sp_20chr_5ev_mild | public | mirror_direct | 150 | 0 | 341 | 341 | True | 0.31 | 0.00 | 0.62 | 7 | 50.5 | 8 | complete |
| stress_6sp_20chr_5ev_mild | pre_hybrid | mirror_selective | 150 | 0 | 341 | 341 | True | 0.20 | 0.00 | 0.21 | 4 | 49.9 | 5 | complete |
| stress_6sp_20chr_5ev_mild | public | mirror_selective | 150 | 0 | 341 | 341 | True | 0.34 | 0.00 | 0.35 | 7 | 50.8 | 8 | complete |
| stress_6sp_20chr_5ev_mild | pre_hybrid | mirror_three | 150 | 0 | 341 | 341 | True | 0.18 | 0.00 | 0.18 | 4 | 50.1 | 5 | complete |
| stress_6sp_20chr_5ev_mild | public | mirror_three | 150 | 0 | 341 | 341 | True | 0.34 | 0.00 | 0.41 | 7 | 50.4 | 8 | complete |
| stress_6sp_20chr_5ev_mild | pre_hybrid | three_control | 150 | 0 | 341 | 341 | True | 0.09 | 0.00 | 0.38 | 5 | 50.8 | 0 | complete |
| stress_6sp_20chr_5ev_mild | public | three_control | 150 | 0 | 341 | 341 | True | 0.34 | 0.00 | 0.41 | 8 | 51.9 | 0 | complete |
| stress_6sp_20chr_5ev_random | pre_hybrid | adaptive_control | 150 | 0 | 341 | 341 | True | 0.18 | 0.00 | 0.42 | 5 | 50.7 | 0 | complete |
| stress_6sp_20chr_5ev_random | public | adaptive_control | 150 | 0 | 341 | 341 | True | 0.32 | 0.00 | 0.43 | 8 | 51.8 | 0 | complete |
| stress_6sp_20chr_5ev_random | pre_hybrid | direct_control | 150 | 0 | 341 | 341 | True | 0.09 | 0.00 | 0.10 | 5 | 50.5 | 0 | complete |
| stress_6sp_20chr_5ev_random | public | direct_control | 150 | 0 | 341 | 341 | True | 0.32 | 0.00 | 0.44 | 8 | 51.9 | 0 | complete |
| stress_6sp_20chr_5ev_random | pre_hybrid | mirror_adaptive | 150 | 0 | 341 | 341 | True | 0.19 | 0.00 | 0.19 | 4 | 50.3 | 5 | complete |
| stress_6sp_20chr_5ev_random | public | mirror_adaptive | 150 | 0 | 341 | 341 | True | 0.33 | 0.00 | 0.38 | 7 | 50.8 | 8 | complete |
| stress_6sp_20chr_5ev_random | pre_hybrid | mirror_direct | 150 | 0 | 341 | 341 | True | 0.21 | 0.00 | 0.22 | 4 | 50.3 | 5 | complete |
| stress_6sp_20chr_5ev_random | public | mirror_direct | 150 | 0 | 341 | 341 | True | 0.35 | 0.00 | 0.39 | 7 | 50.8 | 8 | complete |
| stress_6sp_20chr_5ev_random | pre_hybrid | mirror_selective | 150 | 0 | 341 | 341 | True | 0.19 | 0.00 | 0.20 | 4 | 50.4 | 5 | complete |
| stress_6sp_20chr_5ev_random | public | mirror_selective | 150 | 0 | 341 | 341 | True | 0.15 | 0.00 | 0.17 | 7 | 50.8 | 8 | complete |
| stress_6sp_20chr_5ev_random | pre_hybrid | mirror_three | 150 | 0 | 341 | 341 | True | 0.18 | 0.00 | 0.20 | 4 | 50.3 | 5 | complete |
| stress_6sp_20chr_5ev_random | public | mirror_three | 150 | 0 | 341 | 341 | True | 0.33 | 0.00 | 0.40 | 7 | 50.9 | 8 | complete |
| stress_6sp_20chr_5ev_random | pre_hybrid | three_control | 150 | 0 | 341 | 341 | True | 0.19 | 0.00 | 0.21 | 5 | 50.7 | 0 | complete |
| stress_6sp_20chr_5ev_random | public | three_control | 150 | 0 | 341 | 341 | True | 0.32 | 0.00 | 0.43 | 8 | 51.6 | 0 | complete |
| stress_6sp_20chr_5ev_strong | pre_hybrid | adaptive_control | 150 | 0 | 341 | 341 | True | 0.09 | 0.00 | 0.09 | 5 | 50.7 | 0 | complete |
| stress_6sp_20chr_5ev_strong | public | adaptive_control | 150 | 0 | 341 | 341 | True | 0.35 | 0.00 | 0.50 | 8 | 51.8 | 0 | complete |
| stress_6sp_20chr_5ev_strong | pre_hybrid | direct_control | 150 | 0 | 341 | 341 | True | 0.20 | 0.00 | 0.20 | 5 | 50.8 | 0 | complete |
| stress_6sp_20chr_5ev_strong | public | direct_control | 150 | 0 | 341 | 341 | True | 0.15 | 0.00 | 0.19 | 8 | 51.3 | 0 | complete |
| stress_6sp_20chr_5ev_strong | pre_hybrid | mirror_adaptive | 150 | 0 | 341 | 341 | True | 0.18 | 0.00 | 0.17 | 4 | 50.3 | 5 | complete |
| stress_6sp_20chr_5ev_strong | public | mirror_adaptive | 150 | 0 | 341 | 341 | True | 0.33 | 0.00 | 0.39 | 7 | 50.8 | 8 | complete |
| stress_6sp_20chr_5ev_strong | pre_hybrid | mirror_direct | 150 | 0 | 341 | 341 | True | 0.19 | 0.00 | 0.22 | 4 | 50.5 | 5 | complete |
| stress_6sp_20chr_5ev_strong | public | mirror_direct | 150 | 0 | 341 | 341 | True | 0.30 | 0.00 | 0.37 | 7 | 50.8 | 8 | complete |
| stress_6sp_20chr_5ev_strong | pre_hybrid | mirror_selective | 150 | 0 | 341 | 341 | True | 0.19 | 0.00 | 0.18 | 4 | 50.4 | 5 | complete |
| stress_6sp_20chr_5ev_strong | public | mirror_selective | 150 | 0 | 341 | 341 | True | 0.34 | 0.00 | 0.39 | 7 | 50.8 | 8 | complete |
| stress_6sp_20chr_5ev_strong | pre_hybrid | mirror_three | 150 | 0 | 341 | 341 | True | 0.21 | 0.00 | 0.23 | 4 | 49.9 | 5 | complete |
| stress_6sp_20chr_5ev_strong | public | mirror_three | 150 | 0 | 341 | 341 | True | 0.31 | 0.00 | 0.70 | 7 | 50.9 | 8 | complete |
| stress_6sp_20chr_5ev_strong | pre_hybrid | three_control | 150 | 0 | 341 | 341 | True | 0.09 | 0.00 | 0.09 | 5 | 50.6 | 0 | complete |
| stress_6sp_20chr_5ev_strong | public | three_control | 150 | 0 | 341 | 341 | True | 0.32 | 0.00 | 0.44 | 8 | 52.0 | 0 | complete |
| stress_8sp_30chr_8ev_mild | pre_hybrid | adaptive_control | 150 | 0 | 1258 | 1258 | True | 1.37 | 1.37 | 0.69 | 8 | 81.1 | 0 | complete |
| stress_8sp_30chr_8ev_mild | public | adaptive_control | 150 | 0 | 1258 | 1258 | True | 1.57 | 5.09 | 1.06 | 8 | 81.4 | 0 | complete |
| stress_8sp_30chr_8ev_mild | pre_hybrid | direct_control | 150 | 0 | 1258 | 1258 | True | 1.48 | 0.00 | 0.73 | 8 | 60.7 | 0 | complete |
| stress_8sp_30chr_8ev_mild | public | direct_control | 150 | 0 | 1258 | 1258 | True | 1.50 | 0.00 | 1.12 | 8 | 60.2 | 0 | complete |
| stress_8sp_30chr_8ev_mild | pre_hybrid | mirror_adaptive | 150 | 0 | 1258 | 1258 | True | 1.56 | 1.72 | 0.63 | 8 | 80.3 | 8 | complete |
| stress_8sp_30chr_8ev_mild | public | mirror_adaptive | 150 | 0 | 1258 | 1258 | True | 0.68 | 5.00 | 0.38 | 8 | 78.6 | 8 | complete |
| stress_8sp_30chr_8ev_mild | pre_hybrid | mirror_direct | 150 | 0 | 1258 | 1258 | True | 1.42 | 0.00 | 0.39 | 8 | 56.8 | 8 | complete |
| stress_8sp_30chr_8ev_mild | public | mirror_direct | 150 | 0 | 1258 | 1258 | True | 1.52 | 0.00 | 1.10 | 8 | 57.7 | 8 | complete |
| stress_8sp_30chr_8ev_mild | pre_hybrid | mirror_selective | 150 | 0 | 1258 | 1258 | True | 1.37 | 0.00 | 0.65 | 8 | 59.2 | 8 | complete |
| stress_8sp_30chr_8ev_mild | public | mirror_selective | 150 | 0 | 1258 | 1258 | True | 0.68 | 0.00 | 0.43 | 8 | 57.6 | 8 | complete |
| stress_8sp_30chr_8ev_mild | pre_hybrid | mirror_three | 150 | 0 | 1258 | 1258 | True | 1.43 | 1.00 | 0.53 | 8 | 80.1 | 8 | complete |
| stress_8sp_30chr_8ev_mild | public | mirror_three | 150 | 0 | 1258 | 1258 | True | 1.54 | 4.13 | 0.91 | 8 | 78.4 | 8 | complete |
| stress_8sp_30chr_8ev_mild | pre_hybrid | three_control | 150 | 0 | 1258 | 1258 | True | 1.43 | 1.00 | 0.72 | 8 | 81.1 | 0 | complete |
| stress_8sp_30chr_8ev_mild | public | three_control | 150 | 0 | 1258 | 1258 | True | 1.49 | 4.26 | 1.02 | 8 | 81.9 | 0 | complete |
| stress_8sp_30chr_8ev_random | pre_hybrid | adaptive_control | 150 | 0 | 1258 | 1258 | True | 0.69 | 0.44 | 0.34 | 8 | 81.2 | 0 | complete |
| stress_8sp_30chr_8ev_random | public | adaptive_control | 150 | 0 | 1258 | 1258 | True | 1.38 | 3.14 | 0.98 | 8 | 81.9 | 0 | complete |
| stress_8sp_30chr_8ev_random | pre_hybrid | direct_control | 150 | 0 | 1258 | 1258 | True | 1.56 | 0.00 | 0.74 | 8 | 60.1 | 0 | complete |
| stress_8sp_30chr_8ev_random | public | direct_control | 150 | 0 | 1258 | 1258 | True | 1.43 | 0.00 | 1.09 | 8 | 60.9 | 0 | complete |
| stress_8sp_30chr_8ev_random | pre_hybrid | mirror_adaptive | 150 | 0 | 1258 | 1258 | True | 1.47 | 1.09 | 0.54 | 8 | 80.0 | 8 | complete |
| stress_8sp_30chr_8ev_random | public | mirror_adaptive | 150 | 0 | 1258 | 1258 | True | 1.49 | 2.92 | 0.89 | 8 | 78.4 | 8 | complete |
| stress_8sp_30chr_8ev_random | pre_hybrid | mirror_direct | 150 | 0 | 1258 | 1258 | True | 0.68 | 0.00 | 0.18 | 8 | 56.9 | 8 | complete |
| stress_8sp_30chr_8ev_random | public | mirror_direct | 150 | 0 | 1258 | 1258 | True | 1.38 | 0.00 | 0.97 | 8 | 57.7 | 8 | complete |
| stress_8sp_30chr_8ev_random | pre_hybrid | mirror_selective | 150 | 0 | 1258 | 1258 | True | 1.50 | 0.00 | 0.88 | 8 | 59.0 | 8 | complete |
| stress_8sp_30chr_8ev_random | public | mirror_selective | 150 | 0 | 1258 | 1258 | True | 1.52 | 0.00 | 1.00 | 8 | 57.2 | 8 | complete |
| stress_8sp_30chr_8ev_random | pre_hybrid | mirror_three | 150 | 0 | 1258 | 1258 | True | 1.48 | 0.63 | 0.56 | 8 | 80.3 | 8 | complete |
| stress_8sp_30chr_8ev_random | public | mirror_three | 150 | 0 | 1258 | 1258 | True | 1.49 | 1.99 | 0.87 | 8 | 78.4 | 8 | complete |
| stress_8sp_30chr_8ev_random | pre_hybrid | three_control | 150 | 0 | 1258 | 1258 | True | 1.51 | 0.62 | 0.73 | 8 | 80.9 | 0 | complete |
| stress_8sp_30chr_8ev_random | public | three_control | 150 | 0 | 1258 | 1258 | True | 1.56 | 2.42 | 1.23 | 8 | 81.9 | 0 | complete |
| stress_8sp_30chr_8ev_strong | pre_hybrid | adaptive_control | 150 | 0 | 1258 | 1258 | True | 1.51 | 1.50 | 0.72 | 8 | 81.0 | 0 | complete |
| stress_8sp_30chr_8ev_strong | public | adaptive_control | 150 | 0 | 1258 | 1258 | True | 1.48 | 2.42 | 1.05 | 8 | 81.9 | 0 | complete |
| stress_8sp_30chr_8ev_strong | pre_hybrid | direct_control | 150 | 0 | 1258 | 1258 | True | 0.69 | 0.00 | 0.35 | 8 | 60.6 | 0 | complete |
| stress_8sp_30chr_8ev_strong | public | direct_control | 150 | 0 | 1258 | 1258 | True | 1.38 | 0.00 | 1.18 | 8 | 61.0 | 0 | complete |
| stress_8sp_30chr_8ev_strong | pre_hybrid | mirror_adaptive | 150 | 0 | 1258 | 1258 | True | 1.43 | 1.06 | 0.53 | 8 | 79.9 | 8 | complete |
| stress_8sp_30chr_8ev_strong | public | mirror_adaptive | 150 | 0 | 1258 | 1258 | True | 1.54 | 2.48 | 0.81 | 8 | 77.4 | 8 | complete |
| stress_8sp_30chr_8ev_strong | pre_hybrid | mirror_direct | 150 | 0 | 1258 | 1258 | True | 1.37 | 0.00 | 0.36 | 8 | 56.7 | 8 | complete |
| stress_8sp_30chr_8ev_strong | public | mirror_direct | 150 | 0 | 1258 | 1258 | True | 1.85 | 0.00 | 1.05 | 8 | 57.9 | 8 | complete |
| stress_8sp_30chr_8ev_strong | pre_hybrid | mirror_selective | 150 | 0 | 1258 | 1258 | True | 1.35 | 0.00 | 0.81 | 8 | 59.3 | 8 | complete |
| stress_8sp_30chr_8ev_strong | public | mirror_selective | 150 | 0 | 1258 | 1258 | True | 0.68 | 0.00 | 0.43 | 8 | 57.6 | 8 | complete |
| stress_8sp_30chr_8ev_strong | pre_hybrid | mirror_three | 150 | 0 | 1258 | 1258 | True | 1.41 | 0.66 | 0.54 | 8 | 80.3 | 8 | complete |
| stress_8sp_30chr_8ev_strong | public | mirror_three | 150 | 0 | 1258 | 1258 | True | 1.55 | 1.82 | 0.79 | 8 | 77.8 | 8 | complete |
| stress_8sp_30chr_8ev_strong | pre_hybrid | three_control | 150 | 0 | 1258 | 1258 | True | 1.55 | 1.18 | 1.03 | 8 | 80.9 | 0 | complete |
| stress_8sp_30chr_8ev_strong | public | three_control | 150 | 0 | 1258 | 1258 | True | 1.49 | 1.74 | 1.05 | 8 | 81.7 | 0 | complete |

Expected 210 tasks; found 210. Audit case records: 9/9.
Completion is not proof; only matching global bounds count as reported optima.
Equal vs weighted allocation both retain proven-zero components and visit small unresolved models first.
The pre_hybrid start is frozen historical evidence, not the latest known optimum.
Repeat counts and fixture subsets are recorded in tasks.json. Timing differences need repeated confirmation.
Stage timings overlap. Incumbent trajectories are improvements, not global bound trajectories.
AUDIT stress_6sp_20chr_5ev_mild: strict-improvement infeasibility verified
AUDIT stress_6sp_20chr_5ev_strong: strict-improvement infeasibility verified
AUDIT stress_6sp_20chr_5ev_random: strict-improvement infeasibility verified
AUDIT stress_8sp_30chr_8ev_mild: strict-improvement infeasibility verified
AUDIT stress_8sp_30chr_8ev_strong: strict-improvement infeasibility verified
AUDIT stress_8sp_30chr_8ev_random: strict-improvement infeasibility verified
AUDIT stress_10sp_40chr_12ev_mild: strict-improvement infeasibility verified
AUDIT stress_10sp_40chr_12ev_strong: strict-improvement infeasibility verified
AUDIT stress_10sp_40chr_12ev_random: strict-improvement infeasibility verified
